Cufon.replace('h2 ,.list3 a, h3,h4', { fontFamily: 'Alido' });
Cufon.replace('h1 small , h3', { fontFamily: 'Raleway' });
