tinyMCE.addI18n('sl.advhr_dlg',{size:"Vi\u0161ina",noshade:"Brez sen\u010denja",width:"\u0160irina"});
