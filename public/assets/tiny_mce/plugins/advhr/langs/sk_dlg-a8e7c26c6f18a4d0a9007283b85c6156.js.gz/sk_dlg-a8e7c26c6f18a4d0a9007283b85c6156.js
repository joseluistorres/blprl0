tinyMCE.addI18n('sk.advhr_dlg',{size:"V\u00fd\u0161ka",noshade:"Bez tie\u0148a",width:"\u0160\u00edrka"});
