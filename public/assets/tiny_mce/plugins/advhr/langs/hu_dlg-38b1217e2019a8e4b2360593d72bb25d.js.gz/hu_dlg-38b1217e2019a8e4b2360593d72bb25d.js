tinyMCE.addI18n('hu.advhr_dlg',{size:"Magass\u00e1g",noshade:"\u00c1rny\u00e9k n\u00e9lk\u00fcl",width:"Sz\u00e9less\u00e9g"});
