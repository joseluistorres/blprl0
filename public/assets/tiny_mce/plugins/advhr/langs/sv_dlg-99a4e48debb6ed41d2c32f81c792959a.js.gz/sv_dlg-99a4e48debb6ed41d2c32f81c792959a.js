tinyMCE.addI18n('sv.advhr_dlg',{size:"H\u00f6jd",noshade:"Ingen skugga",width:"Bredd"});
