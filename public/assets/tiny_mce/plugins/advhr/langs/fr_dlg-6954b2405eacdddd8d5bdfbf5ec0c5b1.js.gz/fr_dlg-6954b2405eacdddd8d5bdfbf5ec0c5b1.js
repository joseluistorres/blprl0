tinyMCE.addI18n('fr.advhr_dlg',{size:"Hauteur",noshade:"Pas d\'ombre",width:"Largeur"});
