tinyMCE.addI18n('nb.advhr_dlg',{size:"St\u00f8rrelse",noshade:"Ingen skygge",width:"Bredde"});
