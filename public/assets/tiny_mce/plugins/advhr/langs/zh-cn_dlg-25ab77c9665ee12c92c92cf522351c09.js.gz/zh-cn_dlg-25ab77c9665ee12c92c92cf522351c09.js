tinyMCE.addI18n('zh-cn.advhr_dlg',{size:"\u9ad8\u5ea6",noshade:"\u65e0\u9634\u5f71",width:"\u5bbd\u5ea6"});
