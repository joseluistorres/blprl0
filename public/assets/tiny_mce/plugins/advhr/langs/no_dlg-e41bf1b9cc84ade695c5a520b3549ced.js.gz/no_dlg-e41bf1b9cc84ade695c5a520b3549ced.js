tinyMCE.addI18n('no.advhr_dlg',{size:"H\u00f8yde",noshade:"Ingen skygge",width:"Bredde"});
