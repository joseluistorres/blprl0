tinyMCE.addI18n('cs.advhr_dlg',{size:"V\u00fd\u0161ka",noshade:"Bez st\u00ednu",width:"\u0160\u00ed\u0159ka"});
