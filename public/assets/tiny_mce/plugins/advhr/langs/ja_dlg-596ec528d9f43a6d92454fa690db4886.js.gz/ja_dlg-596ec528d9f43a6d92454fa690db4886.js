tinyMCE.addI18n('ja.advhr_dlg',{size:"\u9ad8\u3055",noshade:"\u5f71\u306a\u3057",width:"\u5e45"});
