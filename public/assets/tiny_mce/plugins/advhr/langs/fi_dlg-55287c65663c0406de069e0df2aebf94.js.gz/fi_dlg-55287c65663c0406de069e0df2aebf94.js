tinyMCE.addI18n('fi.advhr_dlg',{size:"Korkeus",noshade:"Ei varjoa",width:"Leveys"});
