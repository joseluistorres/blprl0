tinyMCE.addI18n('da.advhr_dlg',{size:"H\u00f8jde",noshade:"Ingen skygge",width:"Bredde"});
