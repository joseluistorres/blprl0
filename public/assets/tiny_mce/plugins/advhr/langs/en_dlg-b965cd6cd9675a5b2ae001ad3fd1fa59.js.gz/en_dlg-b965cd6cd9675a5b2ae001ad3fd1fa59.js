tinyMCE.addI18n('en.advhr_dlg',{size:"Height",noshade:"No shadow",width:"Width"});
