tinyMCE.addI18n('pt.advhr_dlg',{size:"Altura",noshade:"Sem sombra",width:"Largura"});
