tinyMCE.addI18n('pl.advhr_dlg',{size:"Wysoko\u015b\u0107",noshade:"Bez cienia",width:"Szeroko\u015b\u0107"});
