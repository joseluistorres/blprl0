tinyMCE.addI18n('ca.advhr_dlg',{size:"Al\u00e7ada",noshade:"Sense sombra",width:"Amplada"});
