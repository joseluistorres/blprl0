tinyMCE.addI18n('pt.paste_dlg',{word_title:"Use CTRL+V para colar o texto na janela.",text_linebreaks:"Manter quebras de linha",text_title:"Use CTRL+V para colar o texto na janela."});
